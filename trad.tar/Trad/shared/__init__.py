"""Shared utilities package (DB, logging, etc.)."""
