"""Meta-controller package for strategy decisions."""
