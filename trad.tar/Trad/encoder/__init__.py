"""Encoder package for representation learning."""
