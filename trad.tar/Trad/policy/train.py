#!/usr/bin/env python3
"""
Stub PPO training with the CryptoTradingEnv. Replace data-driven returns and proper reward.
"""
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env

from trading_env import CryptoTradingEnv


def make_env():
    symbols = ["BTC/USDT", "ETH/USDT"]
    return CryptoTradingEnv(symbols=symbols, window=200)


def main():
    env = make_vec_env(make_env, n_envs=1)
    model = PPO("MlpPolicy", env, verbose=1)
    model.learn(total_timesteps=1000)
    model.save("models/ppo_trader.zip")
    print("Saved models/ppo_trader.zip")


if __name__ == "__main__":
    main()
