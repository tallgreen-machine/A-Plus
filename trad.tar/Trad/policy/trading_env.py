import gymnasium as gym
from gymnasium import spaces
import numpy as np
from typing import Dict, Any

from shared.db import get_db_conn


class CryptoTradingEnv(gym.Env):
    metadata = {"render.modes": ["human"]}

    def __init__(self, symbols: list[str], window: int = 200):
        super().__init__()
        self.symbols = symbols
        self.window = window
        self.n_assets = len(symbols)

        # Observations: embeddings per asset (128 each), position weights per asset, cash, regime one-hot (3), conviction (1)
        emb_dim = 128
        obs_dim = self.n_assets * emb_dim + self.n_assets + 1 + 3 + 1
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32)

        # Action: target weights per asset in [0,1]; residual goes to cash (long-only)
        self.action_space = spaces.Box(low=0.0, high=1.0, shape=(self.n_assets,), dtype=np.float32)

        # State buffers
        self._weights = np.zeros(self.n_assets, dtype=np.float32)
        self._cash = 1.0
        self._last_obs = None

    def _fetch_latest_embedding(self, symbol: str):
        with get_db_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT embedding FROM current_embeddings
                    WHERE symbol = %s
                    ORDER BY ts DESC
                    LIMIT 1
                    """,
                    (symbol,),
                )
                row = cur.fetchone()
                if not row:
                    return np.zeros(128, dtype=np.float32)
                emb = row["embedding"] if isinstance(row, dict) else row[0]
                return np.array(emb, dtype=np.float32)

    def _fetch_market_state(self):
        with get_db_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT current_regime, conviction FROM market_state WHERE id = 1")
                row = cur.fetchone()
                if not row:
                    return np.array([0, 1, 0], dtype=np.float32), 0.0  # default NEUTRAL
                regime = row["current_regime"] if isinstance(row, dict) else row[0]
                conviction = float(row["conviction"] if isinstance(row, dict) else row[1])
        one_hot = np.array(
            [1, 0, 0] if regime == "BEARISH" else ([0, 0, 1] if regime == "BULLISH" else [0, 1, 0]),
            dtype=np.float32,
        )
        return one_hot, conviction

    def _fetch_policy_config(self):
        with get_db_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT reward_weights, risk_params FROM policy_config WHERE id = 1")
                row = cur.fetchone()
                if not row:
                    return {"sharpe": 0.6, "pnl": 0.3, "drawdown": -0.1, "turnover": -0.1}, {"max_pos": 0.15}
                rw = row["reward_weights"] if isinstance(row, dict) else row[0]
                rp = row["risk_params"] if isinstance(row, dict) else row[1]
                return rw, rp

    def reset(self, *, seed: int | None = None, options: Dict[str, Any] | None = None):
        super().reset(seed=seed)
        self._weights[:] = 0.0
        self._cash = 1.0
        obs = self._build_observation()
        self._last_obs = obs
        return obs, {}

    def step(self, action):
        action = np.clip(action, self.action_space.low, self.action_space.high)
        # Normalize weights to <=1 total; residual to cash
        w = action.astype(np.float32)
        w = w / max(1.0, w.sum())

        # Apply risk cap per asset
        _, risk_params = self._fetch_policy_config()
        max_pos = float(risk_params.get("max_pos", 0.15))
        w = np.minimum(w, max_pos)
        w = w / max(1.0, w.sum())

        # Compute simple PnL proxy: dot(weights, pseudo-returns)
        # This is a placeholder: replace with real price-based returns from market_data.
        pseudo_returns = np.zeros(self.n_assets, dtype=np.float32)
        reward_weights, _ = self._fetch_policy_config()

        pnl = float(np.dot(w - self._weights, pseudo_returns))
        turnover = float(np.abs(w - self._weights).sum())
        drawdown_penalty = 0.0  # placeholder

        reward = (
            reward_weights.get("pnl", 0.3) * pnl
            + reward_weights.get("turnover", -0.1) * (-turnover)
            + reward_weights.get("drawdown", -0.1) * (-drawdown_penalty)
        )

        self._weights = w
        self._cash = 1.0 - w.sum()

        obs = self._build_observation()
        self._last_obs = obs
        terminated = False
        truncated = False
        info = {"pnl": pnl, "turnover": turnover}
        return obs, reward, terminated, truncated, info

    def _build_observation(self):
        embs = []
        for sym in self.symbols:
            embs.append(self._fetch_latest_embedding(sym))
        embs_vec = np.concatenate(embs, dtype=np.float32) if embs else np.zeros(128, dtype=np.float32)
        regime_one_hot, conviction = self._fetch_market_state()
        obs = np.concatenate([
            embs_vec,
            self._weights.astype(np.float32),
            np.array([self._cash], dtype=np.float32),
            regime_one_hot.astype(np.float32),
            np.array([conviction], dtype=np.float32),
        ], dtype=np.float32)
        return obs

    def render(self):
        pass
