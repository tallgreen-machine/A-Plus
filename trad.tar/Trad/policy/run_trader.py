#!/usr/bin/env python3
"""
Stub live trader: loads latest embeddings + config, predicts action, and logs.
Replace with ccxt execution and real features.
"""
from __future__ import annotations

import numpy as np
from stable_baselines3 import PPO

from trading_env import CryptoTradingEnv


def main():
    symbols = ["BTC/USDT", "ETH/USDT"]
    env = CryptoTradingEnv(symbols=symbols, window=200)
    model = PPO.load("models/ppo_trader.zip")

    obs, _ = env.reset()
    action, _ = model.predict(obs, deterministic=True)
    obs, reward, terminated, truncated, info = env.step(action)
    print({"action": action.tolist(), "reward": float(reward), "info": info})


if __name__ == "__main__":
    main()
